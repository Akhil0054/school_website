// @ts-ignore
import Swiper from './types/swiper-class.d.ts';

export default Swiper;
export { Swiper };
