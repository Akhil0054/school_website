// === end sticky top === 

AOS.init();

window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar-initial');
    if (window.scrollY > 50) { // Adjust scroll value as needed
      navbar.classList.add('navbar-scrolled');
    } else {
      navbar.classList.remove('navbar-scrolled');
    }
  });
  
// === end sticky top === 




  
// =============== start auto counting ================
function startCounting(element) {
  const target = +element.getAttribute('data-target');
  const speed = 50; // Adjust speed of the counting
  const increment = Math.ceil(target / speed);
  let count = 0;

  const updateCount = () => {
      count += increment;
      if (count >= target) {
          element.innerText = target + '+';
      } else {
          element.innerText = count + '+';
          setTimeout(updateCount, 50); // Adjust time delay for smooth counting
      }
  };

  updateCount();
}

// Intersection Observer to detect when section comes into view
const countingSection = document.querySelector('.counting-section');
const counters = document.querySelectorAll('.count-box h2');
let started = false;

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
      if (entry.isIntersecting && !started) {
          counters.forEach(counter => startCounting(counter));
          started = true; // Prevent counting multiple times
      }
  });
}, { threshold: 0.5 });

observer.observe(countingSection);
// =============== end auto counting ================





// === start testimonal ===
var swiper = new Swiper(".mySwiper", {
  effect: "coverflow",
  grabCursor: true,
  centeredSlides: true,
  slidesPerView: "auto",
  coverflowEffect: {
    rotate: 50,
    stretch: 0,
    depth: 100,
    modifier: 1,
    slideShadows: true,
  },
  pagination: {
    el: ".swiper-pagination",
  },
});
// === end testimonal ===















// === start top scroll button ===
window.onscroll = function() {
  const button = document.querySelector('.scroll-to-top');
  if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
      button.classList.add('visible');
  } else {
      button.classList.remove('visible');
  }
};

document.querySelector('.scroll-to-top').onclick = function() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
};



// === end top scroll button ===
